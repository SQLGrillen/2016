USE [master];
GO

IF EXISTS (SELECT * FROM sys.databases WHERE name = 'TheAwesome')
	DROP DATABASE [TheAwesome] 
GO

CREATE DATABASE [TheAwesome] ON PRIMARY 
(name = N'TheAwesome', FILENAME = N'd:\Databases\2016\TheAwesome.mdf')
LOG ON 
(name = N'TheAwesome_log', FILENAME = N'd:\Databases\2016\TheAwesome_log.ldf');
GO

USE TheAwesome;
GO

CREATE TABLE Users
(
    UserId INT IDENTITY(1, 1) PRIMARY KEY,
    UserName VARCHAR(50),
    UserPassword NVARCHAR(10),
	UserDescription NVARCHAR(400)
);
GO

/* Insert 2 users */
INSERT INTO Users(UserName, UserPassword, UserDescription)
SELECT 'Mladen', 'MyHardPwd', 'Yours truly' UNION ALL
SELECT 'ChuckNorris', 'strongPwd', 'Cobra bit him once and then died in excruciating pain 5 days later';
GO

SELECT  *
FROM    ShellHack 

truncate table ShellHack


SELECT  *
FROM    Users

SELECT SUSER_NAME()
SELECT  *
FROM    Users
