/*============================================================================
	File:		0040 - Creation of database and objects for comparision.sql

	Summary:	This script creates a demo database which will be used for
				the future demonstration scripts

	Date:		June 2015

	SQL Server Version: 2008 / 2012 / 2014
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE master;
GO

-- if the database exists we drop it for a brand new database
IF db_id('demo_db') IS NOT NULL
BEGIN
	RAISERROR ('Database demo_db will be dropped first!', 0, 0) WITH NOWAIT;
	ALTER DATABASE demo_db SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
	DROP DATABASE demo_db;
END
GO

RAISERROR ('Database demo_db will be created!', 0, 0) WITH NOWAIT;
CREATE DATABASE demo_db
ON PRIMARY
(
	Name = 'demo_db',
	FILENAME = 'F:\DATA\demo_db.mdf',
	SIZE = 100MB,
	MAXSIZE = 4000MB,
	FILEGROWTH = 100MB
)
LOG ON
(
	NAME = 'demo_log',
	FILENAME = 'F:\DATA\demo_db.ldf',
	SIZE = 100MB,
	MAXSIZE = 1000MB,
	FILEGROWTH = 100MB
);
GO

RAISERROR ('Owner of database demo_db will be set to sa!', 0, 1) WITH NOWAIT;
ALTER AUTHORIZATION ON DATABASE::demo_db TO sa;

-- for the demos concerning fn_dbLog() keep in mind to set the
-- RECOVERY model to full unless you want run investigation later on!
RAISERROR ('Recovery model of database demo_db will be set to SIMPLE!', 0, 1) WITH NOWAIT;
ALTER DATABASE demo_db SET RECOVERY SIMPLE;
GO

-- Now we create two tables for the battle
SET NOCOUNT ON;
USE demo_db;
GO

IF OBJECT_ID('dbo.Addresses_Cluster', 'U') IS NOT NULL
	DROP TABLE dbo.Addresses_Cluster;
	GO

IF OBJECT_ID('dbo.Addresses_Heap', 'U') IS NOT NULL
	DROP TABLE dbo.Addresses_Heap;
	GO

CREATE TABLE dbo.Addresses_Cluster
(
	Id		INT			NOT NULL	IDENTITY (1, 1),
	CCode	CHAR(2)		NOT NULL,
	Street	CHAR(200)	NOT NULL,
	ZIP		CHAR(20)	NOT NULL,
	City	CHAR(200)	NOT NULL,
	State	CHAR(200)	NOT NULL,

	CONSTRAINT pk_Addresses_Cluster PRIMARY KEY CLUSTERED (Id)
);
GO

CREATE TABLE dbo.Addresses_Heap
(
	Id		INT			NOT NULL	IDENTITY (1, 1),
	CCode	CHAR(2)		NOT NULL,
	Street	CHAR(200)	NOT NULL,
	ZIP		CHAR(20)	NOT NULL,
	City	CHAR(200)	NOT NULL,
	State	CHAR(200)	NOT NULL
);
GO

UPDATE	CustomerOrders.dbo.Addresses
SET		CCode = 'US'
WHERE	Id <= 15000;
GO

-- Insert a few addresses from outside US into the table
INSERT INTO CustomerOrders.dbo.Addresses WITH (TABLOCK)
(Street, CCode, ZIP, City, State)
SELECT	Street, CCode, ZIP, City, ISNULL(TA.State, 'Somewhere')
FROM	dbCustomer.dbo.tblAddresses AS TA;
GO

-- We first create two tables for the comparision
INSERT INTO dbo.Addresses_Cluster (CCode, Street, ZIP, City, State)
SELECT	CCode, Street, ZIP, City, State
FROM	CustomerOrders.dbo.Addresses WITH (TABLOCK);
GO 10

INSERT INTO dbo.Addresses_Heap (CCode, Street, ZIP, City, State)
SELECT	CCode, Street, ZIP, City, State
FROM	CustomerOrders.dbo.Addresses WITH (TABLOCK);
GO 10

-- Now both tables will get a non covering index on the CCode
CREATE INDEX ix_Addresses_HEAP_CCode ON dbo.Addresses_Heap (CCode);
CREATE INDEX ix_Addresses_Cluster_CCode ON dbo.Addresses_Cluster (CCode);
GO
