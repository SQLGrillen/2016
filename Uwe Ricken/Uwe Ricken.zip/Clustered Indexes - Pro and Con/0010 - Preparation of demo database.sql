/*============================================================================
	File:		0011 - restore demo database from existing backup.sql

	Summary:	This script creates a demo database which will be used for
				the future demonstration scripts

	Date:		M�rz 2015

	SQL Server Version: 2008 / 2012 / 2014
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE master;
GO

IF DB_ID('CustomerOrders') IS NOT NULL
BEGIN
	ALTER DATABASE CustomerOrders SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
	DROP DATABASE [CustomerOrders];
END
GO

RESTORE DATABASE CustomerOrders FROM DISK = 'S:\BACKUP\CustomerOrders.bak'
WITH 
	MOVE 'CustomerOrders_Data' TO 'F:\DATA\CustomerOrders.mdf',
	MOVE 'CustomerOrders_Log' TO 'F:\DATA\CustomerOrders.ldf',
	REPLACE,
	STATS = 10;
GO

ALTER AUTHORIZATION ON DATABASE::CustomerOrders TO SA;
ALTER DATABASE CustomerOrders SET COMPATIBILITY_LEVEL = 110;
GO
