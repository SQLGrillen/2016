/*============================================================================
	File:		0050 - HEAP vs CLUSTER - SELECT.sql

	Summary:	This script demonstrates the functionality of non clustered
				indexes in a HEAP. This script is part of the session:
				Clustered Indexes - PRO and CON.

	Attention:	This script will use undocumented functions of Microsoft SQL Server.
				Use this script not in a productive environment!

	Date:		June 2015

	SQL Server Version: 2012 / 2014
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE demo_db;
GO

SET NOCOUNT ON;
SET STATISTICS IO ON;
GO

/*
	1. Run a SELECT on both tables for a dedicated ID
	Both queries will run with MAXDOP 1 to avoid "wrong" executions
	while a performant index seek is much better than an index scan which
	may predict parallel executions!
*/
-- Kahoot
SELECT * FROM dbo.Addresses_Cluster WHERE Id = 7575
OPTION (RECOMPILE, MAXDOP 1);
GO

SELECT * FROM dbo.Addresses_Heap WHERE Id = 7575
OPTION (RECOMPILE, MAXDOP 1);
GO

-- make the filter visible if a FILTER-predicate is used!
SELECT * FROM dbo.Addresses_Cluster WHERE Id = 7575
OPTION (RECOMPILE, MAXDOP 1, QUERYTRACEON 9130);

SELECT * FROM dbo.Addresses_Heap WHERE Id = 7575
OPTION (RECOMPILE, MAXDOP 1, QUERYTRACEON 9130)
GO

-- Kahoot
SELECT TOP 1 * FROM dbo.Addresses_Cluster WHERE Id = 7575
OPTION (RECOMPILE, MAXDOP 1);
GO

SELECT TOP 1 * FROM dbo.Addresses_Heap WHERE Id = 7575
OPTION (RECOMPILE, MAXDOP 1);
GO


/*
	Because we KNOW that each ID is unique we could use TOP 1
	as long as we use ID <= 21 the IO will be better to equal
	to the clustered index
*/
SELECT TOP 1 * FROM dbo.Addresses_Cluster WHERE Id = 21
OPTION (RECOMPILE, MAXDOP 1, QUERYTRACEON 9130);
GO

SELECT TOP 1 * FROM dbo.Addresses_Heap WHERE Id = 21
OPTION (RECOMPILE, MAXDOP 1, QUERYTRACEON 9130);
GO

/*
	The benefit of the SEEK will be destroyed when an attribute will
	be selected which has NO index!
*/
PRINT '----------------- CLUSTER -----------------'
SELECT	STATE				AS	State,
		COUNT_BIG(*)		AS	Addresses
FROM	dbo.Addresses_Cluster
GROUP BY
		State
ORDER BY
		State
OPTION	(RECOMPILE, MAXDOP 1);
GO

PRINT '----------------- HEAP -----------------'
SELECT	STATE				AS	State,
		COUNT_BIG(*)		AS	Addresses
FROM	dbo.Addresses_Heap
GROUP BY
		State
ORDER BY
		State
OPTION	(RECOMPILE, MAXDOP 1);
GO

/* ok - the HEAP performs better because of... ? */
SELECT	QUOTENAME(ISNULL(i.name, 'HEAP'))		AS	IndexName,
		DDIPS.index_id,
		DDIPS.index_level,
		DDIPS.page_count,
		DDIPS.record_count,
		DDIPS.min_record_size_in_bytes,
		DDIPS.max_record_size_in_bytes
FROM	sys.indexes AS I
		CROSS APPLY sys.dm_db_index_physical_stats
		(
			DB_ID(),
			i.object_id,
			i.index_id,
			NULL,
			'DETAILED'
		) AS DDIPS
WHERE	i.object_id IN
		(OBJECT_ID('dbo.Addresses_Heap', 'U'), OBJECT_ID('dbo.Addresses_Cluster', 'U')) AND
		i.index_id IN (0, 1) -- only the tables!
ORDER BY
		i.object_id,
		i.index_id,
		DDIPS.index_level;
GO

/*
	but what will happen if an aggregation is based on an indexed attribute!
	Check the IO of the HEAP - it is larger than the CI! Why?
*/
PRINT '----------------- CLUSTER -----------------'
SELECT	CCode				AS	CCode,
		COUNT_BIG(*)		AS	Addresses
FROM	dbo.Addresses_Cluster
GROUP BY
		CCode
ORDER BY
		CCode
OPTION	(RECOMPILE, MAXDOP 1);
GO

PRINT '----------------- HEAP -----------------'
SELECT	CCode				AS	CCode,
		COUNT_BIG(*)		AS	Addresses
FROM	dbo.Addresses_Heap
GROUP BY
		CCode
ORDER BY
		CCode
OPTION	(RECOMPILE, MAXDOP 1);
GO

-- what will be the differences if a non covered index will be used?
-- first we take only a FEW records
SELECT	*
FROM	dbo.Addresses_Cluster
WHERE	CCode = 'CH';
GO

SELECT	*
FROM	dbo.Addresses_Heap
WHERE	CCode = 'CH';
GO

-- ok - let's take a few more :)
SELECT	*
FROM	dbo.Addresses_Cluster
WHERE	CCode = 'DE';
GO

SELECT	*
FROM	dbo.Addresses_Heap
WHERE	CCode = 'DE';
GO

SELECT	*
FROM	dbo.Addresses_Cluster
WHERE	CCode = 'US';
GO

SELECT	*
FROM	dbo.Addresses_Heap
WHERE	CCode = 'US';
GO

-- what will happen if we have a whole bunch of data?
SELECT	*
FROM	dbo.Addresses_Cluster WITH (INDEX (ix_Addresses_Cluster_CCode))
WHERE	CCode = 'US';
GO

SELECT	*
FROM	dbo.Addresses_Heap WITH (INDEX (ix_Addresses_Heap_CCode))
WHERE	CCode = 'US';
GO

/*
	After all tests have been done the database will be cleared!
	This is only because of the BETTER demonstration of the next
	example!
*/
IF OBJECT_ID('dbo.Addresses_Cluster', 'U') IS NOT NULL
	DROP TABLE dbo.Addresses_Cluster;
	GO

IF OBJECT_ID('dbo.Addresses_Heap', 'U') IS NOT NULL
	DROP TABLE dbo.Addresses_Heap;
	GO
