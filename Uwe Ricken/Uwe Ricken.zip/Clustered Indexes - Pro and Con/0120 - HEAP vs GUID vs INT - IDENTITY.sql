/*============================================================================
	File:		0120 - GUID vs INT - IDENTITY.sql

	Summary:	This script creates a demo database which will be used for
				the future demonstration scripts


	Date:		M�rz 2014

	SQL Server Version: 2008 / 2012
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE master;
GO

-- if the database exists we drop it for a brand new database
IF db_id('demo_db') IS NOT NULL
BEGIN
	RAISERROR ('Database demo_db will be dropped first!', 0, 0) WITH NOWAIT;
	ALTER DATABASE demo_db SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
	DROP DATABASE demo_db;
END
GO

-- and create a new demo database
CREATE DATABASE [demo_db]
ON PRIMARY
(
	NAME = N'demo_db_01',
	FILENAME = N'S:\MSSQL12.SQL_2014\MSSQL\DATA\demo_db_01.mdf',
	SIZE = 2000MB,
	MAXSIZE = 100000MB,
	FILEGROWTH = 100MB
)
--,(
--	NAME = N'demo_db_02',
--	FILENAME = N'S:\MSSQL11.SQL_2012\MSSQL\DATA\demo_db_02.ndf',
--	SIZE = 2000MB,
--	MAXSIZE = 100000MB,
--	FILEGROWTH = 100MB
--)
--,(
--	NAME = N'demo_db_03',
--	FILENAME = N'S:\MSSQL11.SQL_2012\MSSQL\DATA\demo_db_03.ndf',
--	SIZE = 2000MB,
--	MAXSIZE = 100000MB,
--	FILEGROWTH = 100MB
--)
--,(
--	NAME = N'demo_db_04',
--	FILENAME = N'S:\MSSQL11.SQL_2012\MSSQL\DATA\demo_db_04.ndf',
--	SIZE = 2000MB,
--	MAXSIZE = 100000MB,
--	FILEGROWTH = 100MB
--)
LOG ON
(
	NAME = N'demo_log',
	--FILENAME = N'S:\MSSQL11.SQL_2012\MSSQL\DATA\demo_db.ldf',
	FILENAME = N'S:\MSSQL12.SQL_2014\MSSQL\DATA\demo_db.ldf',
	SIZE = 500MB,
	MAXSIZE = 1000MB,
	FILEGROWTH = 100MB
);
GO

ALTER AUTHORIZATION ON DATABASE::demo_db TO sa;
ALTER DATABASE [demo_db] SET RECOVERY SIMPLE;
GO

USE demo_db;
GO

-- table with contigious numbers as clustered key
CREATE TABLE dbo.numeric_table
(
	Id	INT			NOT NULL	IDENTITY(1, 1),
	c1	CHAR(400)	NOT NULL	DEFAULT ('just a filler'),
	
	CONSTRAINT pk_numeric_table PRIMARY KEY CLUSTERED (Id)
);
GO

-- table with random guid as clustered key
CREATE TABLE dbo.guid_table
(
	Id	UNIQUEIDENTIFIER	NOT NULL	ROWGUIDCOL	DEFAULT(NEWID()),
	c1	CHAR(388)			NOT NULL	DEFAULT ('just a filler'),
	
	CONSTRAINT pk_guid_table PRIMARY KEY CLUSTERED (Id)
);
GO

-- heap with NO ordering element
CREATE TABLE dbo.heap_table
(
	Id	INT			NOT NULL	IDENTITY(1, 1),
	c1	CHAR(400)	NOT NULL	DEFAULT ('just a filler')
);
GO

-- Procedure for insertion of 1,000 records in numeric_table
CREATE PROC dbo.proc_insert_data
	@type varchar(10)
AS
	SET NOCOUNT ON

	DECLARE	@i INT = 1;

	IF @type = 'numeric'
	BEGIN
		WHILE @i <= 1000
		BEGIN
			INSERT INTO dbo.numeric_table DEFAULT VALUES
			SET @i += 1;
		END

		RETURN;
	END
	
	IF @type = 'guid'
	BEGIN
		WHILE @i <= 1000
		BEGIN
			INSERT INTO dbo.guid_table DEFAULT VALUES
			SET @i += 1;
		END

		RETURN;
	END
			
	WHILE @i <= 1000
	BEGIN
		INSERT INTO dbo.heap_table DEFAULT VALUES
		SET @i += 1;
	END


	SET NOCOUNT OFF;
GO

CHECKPOINT;
GO
/*
	ostress -E -SNB-LENOVO-I\SQL_2014 -Q"EXEC dbo.proc_insert_data 'heap';" -n100 -ddemo_db -q
*/

DBCC SQLPERF('sys.dm_os_wait_stats', 'CLEAR');
GO

SELECT	DOWT.wait_type,
		DOWT.resource_description,
		COUNT_BIG(DOWT.session_id)		AS	no_sessions,
		SUM(DOWT.wait_duration_ms)		AS	sum_ms
FROM	sys.dm_exec_sessions AS DES INNER JOIN sys.dm_os_waiting_tasks AS DOWT
		ON (DES.session_id = DOWT.session_id)
WHERE	DES.is_user_process = 1
GROUP BY
		DOWT.wait_type,
		DOWT.resource_description;
GO

WITH [Waits] AS
(
	SELECT	[wait_type],
			[wait_time_ms] / 1000.0 AS [WaitS],
			([wait_time_ms] - [signal_wait_time_ms]) / 1000.0 AS [ResourceS],
			[signal_wait_time_ms] / 1000.0 AS [SignalS],
			[waiting_tasks_count] AS [WaitCount],
			100.0 * [wait_time_ms] / SUM ([wait_time_ms]) OVER() AS [Percentage],
			ROW_NUMBER() OVER(ORDER BY [wait_time_ms] DESC) AS [RowNum]
    FROM	sys.dm_os_wait_stats
    WHERE	[wait_type] NOT IN
	(
		N'BROKER_EVENTHANDLER',         N'BROKER_RECEIVE_WAITFOR',
		N'BROKER_TASK_STOP',            N'BROKER_TO_FLUSH',
		N'BROKER_TRANSMITTER',          N'CHECKPOINT_QUEUE',
		N'CHKPT',                       N'CLR_AUTO_EVENT',
		N'CLR_MANUAL_EVENT',            N'CLR_SEMAPHORE',
		N'DBMIRROR_DBM_EVENT',          N'DBMIRROR_EVENTS_QUEUE',
		N'DBMIRROR_WORKER_QUEUE',       N'DBMIRRORING_CMD',
		N'DIRTY_PAGE_POLL',             N'DISPATCHER_QUEUE_SEMAPHORE',
		N'EXECSYNC',                    N'FSAGENT',
		N'FT_IFTS_SCHEDULER_IDLE_WAIT', N'FT_IFTSHC_MUTEX',
		N'HADR_CLUSAPI_CALL',           N'HADR_FILESTREAM_IOMGR_IOCOMPLETION',
		N'HADR_LOGCAPTURE_WAIT',        N'HADR_NOTIFICATION_DEQUEUE',
		N'HADR_TIMER_TASK',             N'HADR_WORK_QUEUE',
		N'KSOURCE_WAKEUP',              N'LAZYWRITER_SLEEP',
		N'LOGMGR_QUEUE',                N'ONDEMAND_TASK_QUEUE',
		N'PWAIT_ALL_COMPONENTS_INITIALIZED',
		N'QDS_PERSIST_TASK_MAIN_LOOP_SLEEP',
		N'QDS_CLEANUP_STALE_QUERIES_TASK_MAIN_LOOP_SLEEP',
		N'REQUEST_FOR_DEADLOCK_SEARCH', N'RESOURCE_QUEUE',
		N'SERVER_IDLE_CHECK',           N'SLEEP_BPOOL_FLUSH',
		N'SLEEP_DBSTARTUP',             N'SLEEP_DCOMSTARTUP',
		N'SLEEP_MASTERDBREADY',         N'SLEEP_MASTERMDREADY',
		N'SLEEP_MASTERUPGRADED',        N'SLEEP_MSDBSTARTUP',
		N'SLEEP_SYSTEMTASK',            N'SLEEP_TASK',
		N'SLEEP_TEMPDBSTARTUP',         N'SNI_HTTP_ACCEPT',
		N'SP_SERVER_DIAGNOSTICS_SLEEP', N'SQLTRACE_BUFFER_FLUSH',
		N'SQLTRACE_INCREMENTAL_FLUSH_SLEEP',
		N'SQLTRACE_WAIT_ENTRIES',       N'WAIT_FOR_RESULTS',
		N'WAITFOR',                     N'WAITFOR_TASKSHUTDOWN',
		N'WAIT_XTP_HOST_WAIT',          N'WAIT_XTP_OFFLINE_CKPT_NEW_LOG',
		N'WAIT_XTP_CKPT_CLOSE',         N'XE_DISPATCHER_JOIN',
		N'XE_DISPATCHER_WAIT',          N'XE_TIMER_EVENT',
		N'QDS_SHUTDOWN_QUEUE')
	AND	waiting_tasks_count > 0
	)
SELECT	MAX ([W1].[wait_type]) AS [WaitType],
		CAST (MAX ([W1].[WaitS]) AS DECIMAL (16,2)) AS [Wait_S],
		CAST (MAX ([W1].[ResourceS]) AS DECIMAL (16,2)) AS [Resource_S],
		CAST (MAX ([W1].[SignalS]) AS DECIMAL (16,2)) AS [Signal_S],
		MAX ([W1].[WaitCount]) AS [WaitCount],
		CAST (MAX ([W1].[Percentage]) AS DECIMAL (5,2)) AS [Percentage],
		CAST ((MAX ([W1].[WaitS]) / MAX ([W1].[WaitCount])) AS DECIMAL (16,4)) AS [AvgWait_S],
		CAST ((MAX ([W1].[ResourceS]) / MAX ([W1].[WaitCount])) AS DECIMAL (16,4)) AS [AvgRes_S],
		CAST ((MAX ([W1].[SignalS]) / MAX ([W1].[WaitCount])) AS DECIMAL (16,4)) AS [AvgSig_S],
		'http://documentation.red-gate.com/display/SM4/' + W1.wait_type AS [DocumentLink]
FROM	[Waits] AS [W1] INNER JOIN [Waits] AS [W2]
		ON ([W2].[RowNum] <= [W1].[RowNum])
GROUP BY
		[W1].[RowNum],
		W1.wait_type
HAVING	SUM ([W2].[Percentage]) - MAX ([W1].[Percentage]) < 99.9;
GO

SELECT	OBJECT_NAME(object_id),
		index_type_desc,
		fragment_count,
		page_count,
		record_count,
		avg_fragmentation_in_percent,
		avg_page_space_used_in_percent
FROM	sys.dm_db_index_physical_stats
(
	DB_ID(),
	OBJECT_ID('dbo.heap', 'U'),
	NULL,
	NULL,
	'DETAILED'
) AS DDIPS;
GO

SELECT	OBJECT_NAME(object_id),
		index_type_desc,
		fragment_count,
		page_count,
		record_count,
		avg_fragmentation_in_percent,
		avg_page_space_used_in_percent
FROM sys.dm_db_index_physical_stats
(
	DB_ID(),
	OBJECT_ID('dbo.guid_table', 'U'),
	1,
	NULL,
	'DETAILED'
) AS DDIPS;
GO

SELECT	OBJECT_NAME(object_id),
		index_type_desc,
		fragment_count,
		page_count,
		record_count,
		avg_fragmentation_in_percent,
		avg_page_space_used_in_percent
FROM	sys.dm_db_index_physical_stats
(
	DB_ID(),
	OBJECT_ID('dbo.numeric_table', 'U'),
	1,
	NULL,
	'DETAILED'
) AS DDIPS;
GO
